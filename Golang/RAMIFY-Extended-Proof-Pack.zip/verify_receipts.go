package main

import (
  "bytes"
  "crypto/ed25519"
  "crypto/sha256"
  "encoding/base64"
  "encoding/hex"
  "encoding/json"
  "fmt"
  "os"
  "path/filepath"
)

func readObject(path string) (map[string]any, error) {
  raw, err := os.ReadFile(path); if err != nil { return nil, err }
  var out map[string]any
  dec := json.NewDecoder(bytes.NewReader(raw)); dec.UseNumber()
  if err := dec.Decode(&out); err != nil { return nil, err }
  return out, nil
}
func canonical(m map[string]any) []byte {
  c := make(map[string]any, len(m))
  for k,v := range m { if k != "payload_hash" && k != "signature" { c[k]=v } }
  b,_ := json.Marshal(c); return b
}
func main() {
  keys, err := readObject(filepath.Join("trust","public_keys.json")); if err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(2) }
  keyHex, _ := keys["ramify:demo:signer:receipt"].(string)
  key, err := hex.DecodeString(keyHex); if err != nil || len(key) != ed25519.PublicKeySize { fmt.Fprintln(os.Stderr,"invalid signer public key"); os.Exit(2) }
  files, _ := filepath.Glob(filepath.Join("receipts","*.json")); if len(files)==0 { fmt.Fprintln(os.Stderr,"no receipts found"); os.Exit(2) }
  failed := 0
  for _, path := range files {
    receipt, err := readObject(path); if err != nil { fmt.Println("FAIL",path,err); failed++; continue }
    digest := sha256.Sum256(canonical(receipt))
    want := "sha256:"+hex.EncodeToString(digest[:])
    hashOK := receipt["payload_hash"] == want
    sig, err := base64.StdEncoding.DecodeString(fmt.Sprint(receipt["signature"]))
    sigOK := err == nil && ed25519.Verify(ed25519.PublicKey(key), digest[:], sig)
    if hashOK && sigOK { fmt.Println("PASS",path) } else { fmt.Printf("FAIL %s hash=%v signature=%v\n",path,hashOK,sigOK); failed++ }
  }
  if failed > 0 { os.Exit(1) }
  fmt.Printf("PASS: %d receipt(s) verified. Historical integrity only; this does not establish current purchase authority.\n",len(files))
}
