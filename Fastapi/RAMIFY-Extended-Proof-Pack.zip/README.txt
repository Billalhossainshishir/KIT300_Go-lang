RAMIFY OS Extended Proof Pack - six-receipt leave-behind
KIT300 ICT Project, University of Tasmania

WHAT THIS IS

This is the extended six-receipt leave-behind, distinct from the browser Quick
Proof Pack (five representative scenarios).  It contains signed decision
receipts, a narrow standalone verifier, and public verification keys only.
It does not contain the RAMIFY application or any private signing key.

HOW TO VERIFY

    python -m pip install -r requirements.txt
    python verify_receipts.py

You may also verify one file:

    python verify_receipts.py receipts/allow.json

The verifier recomputes the canonical SHA-256 payload hash, verifies the
Ed25519 RAMIFY demonstration signature, and confirms that issuer references are
known to the public trust material captured into this pack.  It verifies sealed
record integrity; it deliberately does not turn an old receipt into current
purchase authority.

Run with no arguments, it also checks MANIFEST.json: every file listed is
present and unchanged, all six expected receipts are there, and nothing extra
has been added.  The manifest is signed with the receipts' key, so removing a
receipt together with its manifest line is detected too.

WHICH KEY SIGNED THIS

The public key travels inside this pack, so a PASS proves the receipts match
the key they arrived with.  The verifier prints that key's fingerprint, which
MANIFEST.json also records.  Compare it with the fingerprint in the agreed
handover record before treating the receipts as issued by RAMIFY.

HOW TO CATCH A CHANGE

Edit one character in a receipt and rerun the verifier.  The payload hash and
signature can no longer both verify.  Tamper-evident means a change is visible,
not that the file is impossible to edit.

THE TWO RECEIPTS WORTH READING TOGETHER

proof-consumer.json and proof-procurement.json describe the same product and
evidence.  Their objective posture is the same.  The procurement actor then
narrows what may happen because its commercial policy differs.  Product truth
does not change with the actor.

WHAT IS SYNTHETIC AND WHAT IS NOT

Products, sellers, issuers and evidence are synthetic.  The cryptographic
operations are real SHA-256 and Ed25519 mechanics, but key custody is not
production-grade.  Not for real purchasing, safety, legal or compliance use.
