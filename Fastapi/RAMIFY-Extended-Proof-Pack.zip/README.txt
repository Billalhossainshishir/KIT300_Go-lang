RAMIFY OS Extended Proof Pack - six-receipt leave-behind

This pack is distinct from the browser Quick Proof Pack. It contains six signed
synthetic decision receipts, an explicit manifest, a standalone verifier and
public verification keys only. It contains no RAMIFY application and no private
signing key.

Verify after extraction:
  python -m pip install -r requirements.txt
  python verify_receipts.py

Successful verification establishes historical sealed-record integrity against
the included public demo keys. It does not confer current purchase authority or
rerun RATIFY against current evidence. Products, sellers, issuers and evidence
are synthetic. SHA-256 and Ed25519 mechanics are real; production key custody is
outside this capstone scope.
